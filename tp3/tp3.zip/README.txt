Ne pas mettre l'input entre des apostrophes ou des guillemets dans la ligne de commande pour le programme plast.py
Ils vont etre consideres comme des caracteres et vont fausser les resultats